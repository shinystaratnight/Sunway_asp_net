﻿namespace DealFinder.Response
{
    public class LookupsResponse
    {
        public Lookup[] Lookups { get; set; }
    }
}

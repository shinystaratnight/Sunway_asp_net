﻿namespace DealFinder.Response
{
    public class SearchResponse
    {
        public Property[] Properties { get; set; }
    }
}

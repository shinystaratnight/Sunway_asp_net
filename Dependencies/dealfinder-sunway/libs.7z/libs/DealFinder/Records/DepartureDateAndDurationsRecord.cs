﻿namespace DealFinder.Records
{
    using System;

    public class DepartureDateAndDurationsRecord
    {
        public DateTime DepartureDate { get; set; }
        public string DurationsCSV { get; set; }
    }
}
